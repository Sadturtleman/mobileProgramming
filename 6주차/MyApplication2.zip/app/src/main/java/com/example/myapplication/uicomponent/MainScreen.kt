package com.example.myapplication.uicomponent

import android.content.res.Configuration
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myapplication.R

@Composable
fun MainScreen(modifier: Modifier = Modifier) {
    val imgArray = listOf(
        "arms" to R.drawable.arms,
        "ears" to R.drawable.ears,
        "eyebrows" to R.drawable.eyebrows,
        "eyes" to R.drawable.eyes,
        "glasses" to R.drawable.glasses,
        "hat" to R.drawable.hat,
        "mouth" to R.drawable.mouth,
        "mustache" to R.drawable.mustache,
        "nose" to R.drawable.nose,
        "shoes" to R.drawable.shoes
    ).map { (name, resId) ->
        Triple(name, resId, rememberSaveable { mutableStateOf(true) })
    }

    val configuration = LocalConfiguration.current
    val orientation = configuration.orientation

    if (orientation == Configuration.ORIENTATION_PORTRAIT){
        Column(modifier = modifier.padding(16.dp)) {
            Text("202111351 이준혁")
            Box(modifier = Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                CharImage(R.drawable.body, remember { mutableStateOf(true) })
                imgArray.forEach { (_, resId, state) ->
                    CharImage(img = resId, visibility = state)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            StaggeredGrid(imgArray)
        }
    }
    else{
        Row(modifier = modifier.padding(16.dp)){
            Text("202111351 이준혁")
            Box(modifier = Modifier.fillMaxHeight().height(300.dp), contentAlignment = Alignment.Center){
                CharImage(R.drawable.body, remember { mutableStateOf(true) })
                imgArray.forEach { (_, resId, state) ->
                    CharImage(img = resId, visibility = state)
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            StaggeredGrid(imgArray)
        }
    }

}


@Preview
@Composable
private fun MainScreenPreview() {
    MainScreen()
}