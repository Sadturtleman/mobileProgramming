package com.example.myapplication.uicomponent

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource

@Composable
fun CharImage(img: Int, visibility: MutableState<Boolean>, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = visibility.value
    ) {
        Image(
            painter = painterResource(img),
            contentDescription = null
        )
    }
}
