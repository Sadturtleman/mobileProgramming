package com.example.myapplication.model

import com.example.myapplication.TodoService
import kotlin.system.exitProcess

enum class Number(val number: Int) {
    ADDITEM(1) {
        override fun action() {
            print("등록 메모 : ")
            readlnOrNull()?.let { todoList.addItem(it) }
        }
    },
    DONEITEM(2) {
        override fun action() {
            println("완료 메모 번호: ")
            readlnOrNull()?.toIntOrNull()?.let { todoList.doneTodo(it) }
        }
    },
    SEARCH(3) {
        override fun action() {
            println("검색할 키워드를 입력하세요 : ")
            readlnOrNull()?.let { todoList.searchTodo(it) }
        }
    },
    LISTALL(4) {
        override fun action() {
            todoList.listTodo()
        }
    },
    DESTROY(5) {
        override fun action() {
            println("종료")
            exitProcess(0)
        }
    };

    companion object {
        fun fromInt(number: Int): Number? {
            return entries.find { it.number == number }
        }

        val todoList = TodoService(TodoItemFactory.makeTodoList())
    }

    abstract fun action()
}