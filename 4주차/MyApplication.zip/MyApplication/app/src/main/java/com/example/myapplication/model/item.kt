package com.example.myapplication.model

data class Item(
    val content: String,
    val time: String,
    var status: TodoStatus = TodoStatus.PENDING
) {
    override fun toString(): String {
        return "$content\t$time\t${if (status == TodoStatus.PENDING) "미완료" else "완료"}"
    }

    fun done() = apply { status = TodoStatus.COMPLETED }
    fun toggled() : Item {
        return this.copy(
        status =
            if (status == TodoStatus.PENDING)
                TodoStatus.COMPLETED
            else
                TodoStatus.PENDING
        )
    }
}
