package com.example.myapplication.model

import androidx.compose.runtime.mutableStateListOf
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object TodoItemFactory {
    fun makeTodoList() = mutableStateListOf(
        Item("아침 먹기", "03-18 08:00", TodoStatus.PENDING),
        Item("약 먹기", "03-18 08:30", TodoStatus.COMPLETED),
        Item("점심 먹기", "03-18 12:00", TodoStatus.PENDING),
        Item("약 먹기", "03-18 12:30", TodoStatus.COMPLETED),
        Item("202111351 이준혁", "03-20 13:30", TodoStatus.PENDING)
    )

    fun create(content: String, status: TodoStatus = TodoStatus.PENDING): Item {
        return Item(
            content,
            LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM-dd HH:mm")),
            status
        )
    }
}