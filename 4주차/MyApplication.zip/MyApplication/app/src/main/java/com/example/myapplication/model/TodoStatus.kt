package com.example.myapplication.model

enum class TodoStatus {
    PENDING, COMPLETED
}