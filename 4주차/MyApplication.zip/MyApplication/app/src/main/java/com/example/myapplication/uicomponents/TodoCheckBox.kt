package com.example.myapplication.uicomponents

import androidx.compose.material3.Checkbox
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun TodoCheckBox(
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Checkbox(
        checked = isChecked,
        onCheckedChange = {onCheckedChange(it)}
    )
}

@Preview
@Composable
private fun TodoCheckBoxPreview() {
    TodoCheckBox(isChecked = true, {})
}