package com.example.myapplication

import com.example.myapplication.model.Item
import com.example.myapplication.model.TodoItemFactory

class TodoService(private val todoList: MutableList<Item>) {
    fun listTodo() {
        if (todoList.isEmpty()) {
            println("등록된 메모가 없습니다.")
        } else {
            todoList.forEachIndexed { index, item -> println("${index + 1} : $item") }
        }
    }

    fun addItem(content: String) {
        todoList.add(
            TodoItemFactory.create(content)
        )
        println("메모 등록 완료")
    }

    fun doneTodo(index: Int) {
        todoList[index].done()
        println("메모 완료 처리됨 ${todoList[index]}")
    }

    fun searchTodo(keyword: String) {
        println("검색 결과")
        todoList.forEachIndexed { _, item -> if (keyword in item.content) println(item) }

    }

}