package com.example.myapplication.uicomponents

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapplication.R
import androidx.compose.material3.Text
import androidx.compose.ui.unit.sp


@Composable
fun TodoListTitle(modifier: Modifier = Modifier) {
    Text(
        text = stringResource(id = R.string.todolist_title),
        fontSize = 24.sp,
        fontWeight = FontWeight.ExtraBold
    )
//
}

@Preview
@Composable
private fun TodoListTitlePreview() {
    TodoListTitle()
}
